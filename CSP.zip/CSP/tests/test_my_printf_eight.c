/*
** EPITECH PROJECT, 2019
** test
** File description:
** test
*/

#include  <criterion/criterion.h>
#include  <criterion/redirect.h>
#include "../include/my.h"

Test(my_printf , percentage_hashtag_lx , .init = redirect_all_std)
{
my_printf("%#lx", 2147483647);
cr_assert_stdout_eq_str("0x7fffffff");
}

Test(my_printf , percentage_hashtag_lo , .init = redirect_all_std)
{
my_printf("%#lo", 2147483647);
cr_assert_stdout_eq_str("017777777777");
}

Test(my_printf , percentage_hashtag_ho , .init = redirect_all_std)
{
my_printf("%#ho", 32767);
cr_assert_stdout_eq_str("077777");
}

Test(my_printf , percentage_hashtag_hho , .init = redirect_all_std)
{
my_printf("%#hho", 127);
cr_assert_stdout_eq_str("0177");
}

Test(my_printf , percentage_hashtag_llo , .init = redirect_all_std)
{
my_printf("%#llo", 9223372036854775807);
cr_assert_stdout_eq_str("0777777777777777777777");
}