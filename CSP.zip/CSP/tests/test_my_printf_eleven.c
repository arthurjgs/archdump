/*
** EPITECH PROJECT, 2019
** test
** File description:
** test
*/

#include  <criterion/criterion.h>
#include  <criterion/redirect.h>
#include "../include/my.h"

Test(my_printf , percentage_space_lld , .init = redirect_all_std)
{
my_printf("% lld", 2147483647);
cr_assert_stdout_eq_str(" 2147483647");
}

Test(my_printf , percentage_space_md , .init = redirect_all_std)
{
my_printf("% d", -2147483647);
cr_assert_stdout_eq_str("-2147483647");
}

Test(my_printf , percentage_space_mhd , .init = redirect_all_std)
{
my_printf("% hd", -32767);
cr_assert_stdout_eq_str("-32767");
}

Test(my_printf , percentage_space_mhhd , .init = redirect_all_std)
{
my_printf("% hhd", -127);
cr_assert_stdout_eq_str("-127");
}
