/*
** EPITECH PROJECT, 2019
** test
** File description:
** test
*/

#include  <criterion/criterion.h>
#include  <criterion/redirect.h>
#include "../include/my.h"

Test(my_printf , percentage_s_null , .init = redirect_all_std)
{
    my_printf("%s", NULL);
    cr_assert_stdout_eq_str("(null)");
}

Test(my_printf , percentage_lli , .init = redirect_all_std)
{
my_printf("%lli", 9223372036854775807);
cr_assert_stdout_eq_str("9223372036854775807");
}

Test(my_printf , percentage_llx , .init = redirect_all_std)
{
my_printf("%llx", 9223372036854775807);
cr_assert_stdout_eq_str("7fffffffffffffff");
}

Test(my_printf , percentage_llu , .init = redirect_all_std)
{
my_printf("%llu", 18446744073709551615);
cr_assert_stdout_eq_str("18446744073709551615");
}

Test(my_printf , percentage_hhd , .init = redirect_all_std)
{
my_printf("%hhd", -127);
cr_assert_stdout_eq_str("-127");
}