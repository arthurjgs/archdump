/*
** EPITECH PROJECT, 2019
** delivery
** File description:
** delivery
*/

#include  <criterion/criterion.h>
#include  <criterion/redirect.h>
#include "../include/my.h"

Test(my_printf , percentage_S , .init = redirect_all_std)
{
    char str[] = {'t', 6, 't', 'o', '\0'};

    my_printf("%S", str);
    cr_assert_stdout_eq_str("t\\006to");
}

Test(my_printf , percentage_lld , .init = redirect_all_std)
{
    long long test = 9223372036854775807;

    my_printf("%lld", test);
    cr_assert_stdout_eq_str("9223372036854775807");
}

Test(my_printf , percentage_ld , .init = redirect_all_std)
{
    long test = 40000000000000;

    my_printf("%ld", test);
    cr_assert_stdout_eq_str("40000000000000");
}

Test(my_printf , percentage_hi , .init = redirect_all_std)
{
    short test = 32767;

    my_printf("%hi", test);
    cr_assert_stdout_eq_str("32767");
}

Test(my_printf , percentage_hhi , .init = redirect_all_std)
{
    signed short test = 127;

    my_printf("%hhi", test);
    cr_assert_stdout_eq_str("127");
}
