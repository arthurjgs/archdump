/*
** EPITECH PROJECT, 2019
** delivery
** File description:
** delivery
*/

#include  <criterion/criterion.h>
#include  <criterion/redirect.h>
#include "../include/my.h"

void  redirect_all_std(void)
{
    cr_redirect_stdout ();
    cr_redirect_stderr ();
}

Test(my_printf , simple_string , .init = redirect_all_std)
{
    my_printf("hello  world");
    cr_assert_stdout_eq_str("hello  world");
}

Test(my_printf , percentage_s , .init = redirect_all_std)
{
    my_printf("%s", "Hello");
    cr_assert_stdout_eq_str("Hello");
}

Test(my_printf , percenatge_c , .init = redirect_all_std)
{
    my_printf("%c", 'X');
    cr_assert_stdout_eq_str("X");
}

Test(my_printf , percenatge_d , .init = redirect_all_std)
{
    my_printf("%d", 2147483647);
    cr_assert_stdout_eq_str("2147483647");
}
