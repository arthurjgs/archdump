/*
** EPITECH PROJECT, 2019
** test
** File description:
** test
*/

#include  <criterion/criterion.h>
#include  <criterion/redirect.h>
#include "../include/my.h"

Test(my_printf , percentage_s_lx , .init = redirect_all_std)
{
my_printf("%lx", 2147483647);
cr_assert_stdout_eq_str("7fffffff");
}

Test(my_printf , percentage_lo , .init = redirect_all_std)
{
my_printf("%lo", 2147483647);
cr_assert_stdout_eq_str("17777777777");
}

Test(my_printf , percentage_ho , .init = redirect_all_std)
{
my_printf("%ho", 32767);
cr_assert_stdout_eq_str("77777");
}

Test(my_printf , percentage_hho , .init = redirect_all_std)
{
my_printf("%hho", 127);
cr_assert_stdout_eq_str("177");
}

Test(my_printf , percentage_llo , .init = redirect_all_std)
{
my_printf("%llo", 9223372036854775807);
cr_assert_stdout_eq_str("777777777777777777777");
}