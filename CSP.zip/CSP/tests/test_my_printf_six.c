/*
** EPITECH PROJECT, 2019
** test
** File description:
** test
*/

#include  <criterion/criterion.h>
#include  <criterion/redirect.h>
#include "../include/my.h"

Test(my_printf , percentage_s_lu , .init = redirect_all_std)
{
my_printf("%lu", 4444444444444);
cr_assert_stdout_eq_str("4444444444444");
}

Test(my_printf , percentage_hu , .init = redirect_all_std)
{
my_printf("%hu", 60000);
cr_assert_stdout_eq_str("60000");
}

Test(my_printf , percentage_hhu , .init = redirect_all_std)
{
my_printf("%hhu", 127);
cr_assert_stdout_eq_str("127");
}

Test(my_printf , percentage_hx , .init = redirect_all_std)
{
my_printf("%hx", 32767);
cr_assert_stdout_eq_str("7fff");
}

Test(my_printf , percentage_hhx , .init = redirect_all_std)
{
my_printf("%hhx", 127);
cr_assert_stdout_eq_str("7f");
}