/*
** EPITECH PROJECT, 2019
** test
** File description:
** test
*/

#include  <criterion/criterion.h>
#include  <criterion/redirect.h>
#include "../include/my.h"

Test(my_printf , percentage_plus_d , .init = redirect_all_std)
{
my_printf("%+d", 2147483647);
cr_assert_stdout_eq_str("+2147483647");
}

Test(my_printf , percentage_space_d , .init = redirect_all_std)
{
my_printf("% d", 2147483647);
cr_assert_stdout_eq_str(" 2147483647");
}

Test(my_printf , percentage_space_hd , .init = redirect_all_std)
{
my_printf("% hd", 32767);
cr_assert_stdout_eq_str(" 32767");
}

Test(my_printf , percentage_space_hhd , .init = redirect_all_std)
{
my_printf("% hhd", 127);
cr_assert_stdout_eq_str(" 127");
}

Test(my_printf , percentage_space_ld , .init = redirect_all_std)
{
my_printf("% ld", -44444444444);
cr_assert_stdout_eq_str("-44444444444");
}