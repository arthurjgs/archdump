/*
** EPITECH PROJECT, 2019
** delivery
** File description:
** delivery
*/

#include  <criterion/criterion.h>
#include  <criterion/redirect.h>
#include "../include/my.h"

Test(my_printf , percentage_p , .init = redirect_all_std)
{
    my_printf("%%");
    cr_assert_stdout_eq_str("%%");
}

Test(my_printf , percentage_o , .init = redirect_all_std)
{
    my_printf("%o", 123);
    cr_assert_stdout_eq_str("173");
}

Test(my_printf , percenatge_p_null , .init = redirect_all_std)
{
    char *str = NULL;

    my_printf("%p", str);
    cr_assert_stdout_eq_str("(nil)");
}

Test(my_printf , percenatge_p , .init = redirect_all_std)
{
    char *str = (void *)0x123a;

    my_printf("%p", str);
    cr_assert_stdout_eq_str("0x123a");
}

Test(my_printf , percenatge_d_neg , .init = redirect_all_std)
{
    my_printf("%d", -213);
    cr_assert_stdout_eq_str("-213");
}
