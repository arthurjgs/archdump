/*
** EPITECH PROJECT, 2019
** delivery
** File description:
** delivery
*/

#include  <criterion/criterion.h>
#include  <criterion/redirect.h>
#include "../include/my.h"

Test(my_printf , percentage_i , .init = redirect_all_std)
{
    my_printf("%i", 2147483647);
    cr_assert_stdout_eq_str("2147483647");
}

Test(my_printf , percentage_u , .init = redirect_all_std)
{
    unsigned int test = 4294967295;

    my_printf("%u", test);
    cr_assert_stdout_eq_str("4294967295");
}

Test(my_printf , percenatge_x , .init = redirect_all_std)
{
    my_printf("%x", 123);
    cr_assert_stdout_eq_str("7b");
}

Test(my_printf , percenatge_X , .init = redirect_all_std)
{
    my_printf("%X", 123);
    cr_assert_stdout_eq_str("7B");
}

Test(my_printf , percenatge_b , .init = redirect_all_std)
{
    my_printf("%b", 123);
    cr_assert_stdout_eq_str("1111011");
}
